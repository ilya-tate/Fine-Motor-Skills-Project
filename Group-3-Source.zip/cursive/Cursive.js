let penSize = 1;
let penState = 0;
var input;
let subButton = false;
let displayWord = false;
let trace = false;
let word;
let str;
let words;
let time=0;

function setup() {
  createCanvas(720, 400);
  noStroke();
  //wanted phrase/word
  word = createInput([]);
  word.position(50, 30);
  //ask the user for input
  prompt = createElement('h3', 'Enter your word.');
  //element used to display the inputted phrase/word
  traceWord = createElement('h2', '');
  traceWord.class = 'word';
  prompt.position(50, -10);
  traceWord.position(50, 80);
  //back button
  back = createImg("../BckButton.png");
  back.mousePressed(move);
  back.position(10, 10);
  back.size(30, 30);
}


function draw() {

  rect(230, 037, 50, 19);
//checks if the mouse is over the submit button
  if (mouseX > 0 && mouseX < 720 && mouseY > 0 && mouseY < 400) {
    if (mouseX > 230 && mouseX < 280 && mouseY > 37 && mouseY < 56) {
      subButton = true;
    }
    else {
      subButton = false;
    }
  }

//responsible for the display of user inputted word/phrase
  if (subButton == true && displayWord == true) {
    let words = word.value();
    traceWord.html(words);
  }

  //function responsible for user being able to draw on screen
if (trace == true){
    stroke(0);
    if (mouseIsPressed === true) {
      line(mouseX, mouseY, pmouseX, pmouseY);
    }
  }
}


function mousePressed() {

//checks to see whether or not the 'button' is being hovered over before being clicked on
  if (subButton == true) {
    trace=true;
    displayWord = true;
    time=time+1;
    clear();
    
    //the following is responsible for generating positive feedback to the user
     if (time==2){
    gj=createElement('h4','Good Job!');
     gj.position(300,-35);
    gw.remove();
  }

  if (time==3){
    gj.remove();
    kip=createElement('h4','Keep it up!');
    kip.position(300,-35);
  }
  
  if (time==4){
    kip.remove();
    gw=createElement('h4','Great work!');
    gw.position(300,-35);
    time = 1;
  }
  }
  
//ensures that the mouse tracking is either on the button 'true' or off it 'false'
  if (subButton == false) {
    displayWord = false;
  }
}

function move() {
  window.location.href = "../home/home.html"
}

