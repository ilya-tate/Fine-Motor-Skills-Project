const diameter = 30;
const radius = diameter / 2;
let currSeconds = 99;
let secondsPassed = 0;

let score = 0;

function setup() {
  createCanvas(720, 400);
  bg = loadImage('AimTraining.png');
  frameRate(1);

  back = createImg("../BckButton.png")
  back.mousePressed(move);
  back.position(10, 10);
  back.size(30,30);
}

function draw() { 
  background(bg);
  console.log(mouseX, mouseY)
  
  fill('lavender');
  const circleX = random(diameter, 720 - diameter);
  const circleY = random(diameter + 50, 400 - diameter);
  //console.log(circleX, circleY);
  circle(circleX, circleY, 30);

  // User clicks on screen
  let isClicked = false;
  document.body.addEventListener("click", () => {
    if (!isClicked && currSeconds) checkUserClickedCirlce(circleX, circleY);
    isClicked = true;
  });
  
  fill(0, 0, 0);
  rect(50, 15, 625, 50);

  textSize(25);
  textFont("Anton");
  fill(255, 255, 255);
  text("SCORE: " + score, 300, 50);
  
  currSeconds ? currSeconds-- : gameOver();
  text(currSeconds + " sec", 100, 50);
  secondsPassed++;
  text((score / secondsPassed * 100).toFixed(2)+"%", 500, 50);
  if (currSeconds === 0) frameRate(0);
}

const checkUserClickedCirlce = (circleX, circleY) => {
  //console.log("Cursor", mouseX, mouseY);
  switch (true) {
    // Check X in bounds
    case mouseX > circleX + radius || mouseX < circleX - radius:
      //console.log("Fail test");
      break;
    // Check Y in bounds
    case mouseY > circleY + radius || mouseY < circleY - radius:
      //console.log("Fail test");
      break;
    default:
      //console.log("Pass test");
      score++;
  }
}

const gameOver = () => {
  console.log("Game over");
}

function move() {
  window.location.href="../home/home.html"
}