const diameter = 35;

let xBall = Math.floor(Math.random() * 300) + 50;
let yBall = 50;
let xBallChange = 5;
let yBallChange = 5;

// Variables for the paddle
let xPaddle;
let yPaddle;
const paddleWidth = 200;
const paddleHeight = 350;

let started = false;
let score = 0;

function setup() {
  createCanvas(720, 400);
  bg = loadImage('WallPong.png');

  
  back = createImg("../BckButton.png")
  back.mousePressed(move);
  back.position(10, 10);
  back.size(30,30);
}

function draw() {
  background(bg);
  
  
  // Ball bounces off walls
	xBall += xBallChange;
	yBall += yBallChange;
	if (xBall < diameter / 2 ||  xBall > 720 - 0.5 * diameter) {
		xBallChange *= -1;
  }
	if (yBall < diameter / 2 || yBall > 400 - diameter) {
    yBallChange *= -1;
    if (yBall > 400 - diameter && score > 0) score--;
	}
  
  // Detect collision with paddle
  if (
    (xBall > xPaddle && xBall < xPaddle + paddleWidth) &&
    (yBall + (diameter / 2) >= yPaddle)
  ) {
    xBallChange *= -1;
    yBallChange *= -1;
    score++;
  }
  
  // Draw ball
	fill('lavender');
	noStroke();
	ellipse(xBall, yBall, diameter, diameter);
  
  // Update paddle location
  if (!started) {
    xPaddle = (720 - 200) / 2;
    yPaddle = 400 - 25;
    started = true;
  }
  
  // Draw paddle
  fill(75,0,130);
  noStroke();
  rect(xPaddle, yPaddle, paddleWidth, paddleHeight);
  
  // Draw score
  fill('Black');
  textSize(35);
  textFont("Anton");
	text("Score: " + score, (720 / 2) - 50, 400 * 0.15);
}

function keyPressed () {
  switch (keyCode) {
    case LEFT_ARROW:
      xPaddle -= 50;
      break;
    case RIGHT_ARROW:
      xPaddle += 50;
      break;
  }
}

function move() {
  window.location.href="../home/home.html"
}