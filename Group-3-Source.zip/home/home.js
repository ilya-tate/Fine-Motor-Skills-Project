function setup() {
  createCanvas(720,400);
  bg = loadImage('Descriptions.png');
  
  aim = createImg("Aim Training Button.png")
  aim.mousePressed(moveAim);
  aim.position(31, 77);
  

  wall = createImg("WallPong Button.png")
  wall.mousePressed(moveWall)
  wall.position(31, 295);
  
  
  cursive = createImg("Cursive Button.png");
  cursive.mousePressed(moveCursive);
  cursive.position(31, 186);


  

}

function draw() {
  background(bg);
}

function moveAim() {
  window.location.href="../aimTrainer/aimTrainer.html"
}

function moveWall() {
  window.location.href="../wallpong/wallpong.html"
}

function moveCursive() {
  window.location.href="../cursive/cursive.html"
}