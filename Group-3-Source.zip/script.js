
function setup() {
  createCanvas(720, 400);
  bg = loadImage('Archivals_Start.png');
  
  start = createImg('Start_Buttom.png')
  start.mousePressed(move);
  start.position(8, 8);
  
  }

  function draw() {
    background(bg);
  }

  function move() {
  window.location.href='home/home.html';
  }

  